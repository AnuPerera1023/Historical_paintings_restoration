"""Strict crack detector for wall paintings (replaces the over-eager default).

Why the old one failed: it flagged texture (rough plaster, pigment blotches) and
the cut-out edge of the painting as "damage", so 60-70% of the picture got
repainted and the figure turned into blurry blobs.

This one only keeps thin, dark, LINE-shaped things:
  1. ignore the background (white / transparent areas) and its edge
  2. blackhat filter at several sizes = "dark thin lines on a lighter area"
  3. keep only the strongest responses, never more than `max_fraction` of the image
  4. keep only long, thin connected pieces (cracks), drop round blobs (texture)
"""
import cv2
import numpy as np


def foreground_mask(img_rgb, white_thresh=235, edge_erode=7):
    """True where there is actual painting (not white background)."""
    bg = np.all(img_rgb > white_thresh, axis=2)
    bg = cv2.morphologyEx(bg.astype(np.uint8), cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    fg = (1 - bg).astype(np.uint8)
    # drop tiny specks of "foreground" in the background, then pull away from the edge
    n, lab, stats, _ = cv2.connectedComponentsWithStats(fg, 8)
    keep = np.zeros_like(fg)
    for i in range(1, n):
        if stats[i, cv2.CC_STAT_AREA] > 0.01 * fg.size:
            keep[lab == i] = 1
    if edge_erode > 0:
        keep = cv2.erode(keep, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * edge_erode + 1,) * 2))
    return keep.astype(bool)


def detect_damage_mask(img_rgb, sensitivity=0.6, max_fraction=0.08,
                       min_length=18, min_extent=0.045, dilate=2):
    """Return uint8 mask (0 or 255). sensitivity 0.2 (strict) .. 0.95 (loose)."""
    h, w = img_rgb.shape[:2]
    scale = max(h, w) / 1000.0  # make sizes independent of photo resolution
    fg = foreground_mask(img_rgb, edge_erode=max(4, int(12 * max(scale, 0.5))))
    if fg.sum() < 100:
        return np.zeros((h, w), np.uint8)

    gray = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2GRAY)
    # fill background with local mean so it does not create fake lines
    fill = int(np.median(gray[fg]))
    g = np.where(fg, gray, fill).astype(np.uint8)
    g = cv2.GaussianBlur(g, (0, 0), 0.8)

    resp = np.zeros((h, w), np.float32)
    for k in (7, 13):
        k = max(3, int(k * max(scale, 0.5))) | 1
        bh = cv2.morphologyEx(g, cv2.MORPH_BLACKHAT, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
        resp = np.maximum(resp, bh.astype(np.float32))
    resp[~fg] = 0

    # Hysteresis: "strong" = very dark thin pixels (crack cores). "weak" = slightly
    # less dark pixels. We keep weak regions that touch a strong core, so a crack is
    # followed along its whole length, while isolated texture never starts a crack.
    vals = resp[fg]
    # higher sensitivity -> lower threshold -> more cracks found
    hi_pct = float(np.clip(99.4 - 2.4 * sensitivity, 96.5, 99.4))   # 0.3->P98.7  0.6->P98.0  0.9->P97.2
    thr_hi = max(np.percentile(vals, hi_pct), 20.0)
    thr_lo = max(0.55 * thr_hi, 10.0)
    strong = (resp >= thr_hi) & fg
    weak = ((resp >= thr_lo) & fg).astype(np.uint8)
    n, lab, stats, _ = cv2.connectedComponentsWithStats(weak, 8)
    seeds = np.unique(lab[strong])
    seeds = seeds[seeds > 0]

    # keep only LONG pieces: cracks run across the picture, painted details are short
    diag = float(np.hypot(h, w))
    min_len = max(min_length * max(scale, 0.5), min_extent * diag)
    out = np.zeros((h, w), np.uint8)
    for i in seeds:
        x, y, bw, bh, area = stats[i]
        if float(np.hypot(bw, bh)) >= min_len:
            out[lab == i] = 1

    # safety cap: a "crack" mask covering too much means the photo is not crack-like
    if out.sum() > max_fraction * fg.sum():
        keep = out.astype(bool) & (resp >= np.percentile(resp[out.astype(bool)], 60))
        out = keep.astype(np.uint8)

    if dilate > 0:
        out = cv2.dilate(out, np.ones((2 * dilate + 1,) * 2, np.uint8))
    return (out * 255).astype(np.uint8)
