"""LaMa inpainting through the 'simple-lama-inpainting' package.

Why: it downloads the LaMa weights by itself, so you do not need the repo's own
weight script to work. Install:  pip install simple-lama-inpainting
LaMa is MUCH better than OpenCV for gaps wider than ~5 px, but it invents
texture - so only give it thin masks (cracks), never the whole painting.
"""
import numpy as np
from PIL import Image

_model = None


def available():
    try:
        import simple_lama_inpainting  # noqa: F401
        return True
    except Exception:
        return False


def inpaint_lama(img_rgb, mask):
    global _model
    from simple_lama_inpainting import SimpleLama
    if _model is None:
        _model = SimpleLama()
    out = _model(Image.fromarray(img_rgb), Image.fromarray(mask))
    out = np.array(out)
    h, w = img_rgb.shape[:2]
    return out[:h, :w]  # LaMa may pad to a multiple of 8
