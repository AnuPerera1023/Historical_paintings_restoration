import csv
import os

import gradio as gr

from src.utils.common import overlay_mask
from src.detectors.opencv_crack import detect_damage_mask as opencv_mask
from src.inpainters.opencv_inpaint import inpaint_opencv
from src.detectors.ridge_crack import detect_damage_mask as ridge_mask

META = "data/metadata.csv"  # made by scripts/index_dataset.py


# ---------- NEW: browse your own images by Period -> Site -> Photo ----------
def load_meta():
    tree = {}
    if os.path.exists(META):
        with open(META) as f:
            for r in csv.DictReader(f):
                tree.setdefault(r["period"], {}).setdefault(r["site"], []).append(r)
    return tree


TREE = load_meta()


def sites_for(period):
    sites = sorted(TREE.get(period, {}))
    return gr.update(choices=sites, value=sites[0] if sites else None)


def photos_for(period, site):
    files = sorted(r["file"] for r in TREE.get(period, {}).get(site, []))
    return gr.update(choices=files, value=files[0] if files else None)


def load_sample(period, site, fname):
    for r in TREE.get(period, {}).get(site, []):
        if r["file"] == fname:
            return r["path"]
    return None


# ---------- existing pipeline (unchanged) ----------
def unet_ok():
    try:
        from src.detectors.unet_detector import available as ok
        return ok()
    except Exception:
        return False


def try_lama(img_rgb, mask):
    # 1) easiest: simple-lama-inpainting (auto-downloads weights)
    try:
        from src.inpainters.lama_simple import available, inpaint_lama
        if available():
            return inpaint_lama(img_rgb, mask)
    except Exception:
        pass
    # 2) the repo's own LaMa wrapper (needs models/lama/big-lama.pt)
    try:
        from src.inpainters.lama_inpaint import LamaInpainter
        lama = LamaInpainter()
        if lama.available():
            return lama.inpaint(img_rgb, mask)
    except Exception:
        pass
    return None


# ---------- NEW: presets so the user picks a damage type, not 5 sliders ----------
PRESETS = {
    "Fine cracks (plaster / paint)": dict(sens=0.6, method="telea", radius=2),
    "Scratches / graffiti": dict(sens=0.7, method="telea", radius=3),
    "Flaking / paint loss": dict(sens=0.5, method="ns", radius=5),
}


def apply_preset(name):
    p = PRESETS.get(name)
    if not p:
        return gr.update(), gr.update(), gr.update()
    return p["sens"], p["method"], p["radius"]


def restore(img, detector, use_lama, sensitivity, method, radius, max_pct):
    if img is None:
        return None, None, None, ""
    if detector == "Ridge (recommended)":
        mask = ridge_mask(img, sensitivity=sensitivity, max_fraction=max_pct / 100.0)
    elif detector == "U-Net" and unet_ok():
        try:
            from src.detectors.unet_detector import detect_damage_mask as um
            mask = um(img)
        except Exception:
            mask = ridge_mask(img, sensitivity=sensitivity, max_fraction=max_pct / 100.0)
    else:
        mask = opencv_mask(img, sensitivity=sensitivity)

    frac = 100.0 * float((mask > 0).mean())
    note = f"Marked as damage: {frac:.1f}% of the image."
    # SAFETY: inpainting only works for thin damage. If a big part is marked, the
    # detector is wrong - repainting it would blur the artwork, so do nothing.
    if frac > max_pct:
        note += (f" That is more than your limit of {max_pct:.0f}%, so NOTHING was repainted. "
                 "Lower the sensitivity or use the Ridge detector.")
        return img, overlay_mask(img, mask, 0.45), img, note

    overlay = overlay_mask(img, mask, 0.45)
    restored = try_lama(img, mask) if use_lama else None
    if restored is None:
        restored = inpaint_opencv(img, mask, method=method, radius=radius)
    elif use_lama:
        note += " Filled with LaMa."
    return img, overlay, restored, note


with gr.Blocks(title="Sri Lankan Heritage Painting Restoration") as demo:
    gr.Markdown("# Sri Lankan Heritage Painting Restoration\n"
                "Murals, frescoes and cave paintings - choose a sample or upload your own.")
    with gr.Row():
        with gr.Column():
            # --- sample browser ---
            periods = sorted(TREE)
            dd_period = gr.Dropdown(periods, value=periods[0] if periods else None, label="Period")
            dd_site = gr.Dropdown([], label="Site")
            dd_photo = gr.Dropdown([], label="Photo")
            btn_load = gr.Button("Load sample")

            inp = gr.Image(type="numpy", label="Painting (loaded sample or upload)")
            preset = gr.Radio(list(PRESETS), label="Damage type (preset)")
            det = gr.Radio(["Ridge (recommended)", "OpenCV", "U-Net"], value="Ridge (recommended)", label="Damage detector")
            use_lama = gr.Checkbox(label="Use LaMa for filling (better for wide cracks)", value=False)
            sens = gr.Slider(0.2, 0.95, value=0.6, step=0.05, label="OpenCV detector sensitivity")
            method = gr.Radio(["telea", "ns"], value="telea", label="OpenCV inpaint method")
            rad = gr.Slider(1, 9, value=3, step=1, label="Inpaint radius")
            max_pct = gr.Slider(1, 30, value=10, step=1, label="Safety limit: max % of image allowed to be repainted")
            btn = gr.Button("Restore")
        with gr.Column():
            o1 = gr.Image(type="numpy", label="Original")
            o2 = gr.Image(type="numpy", label="Damage overlay")
            o3 = gr.Image(type="numpy", label="Restored")
            status = gr.Textbox(label="What happened", interactive=False)

    dd_period.change(sites_for, dd_period, dd_site)
    dd_site.change(photos_for, [dd_period, dd_site], dd_photo)
    btn_load.click(load_sample, [dd_period, dd_site, dd_photo], inp)
    preset.change(apply_preset, preset, [sens, method, rad])
    btn.click(fn=restore, inputs=[inp, det, use_lama, sens, method, rad, max_pct], outputs=[o1, o2, o3, status])

if __name__ == "__main__":
    demo.launch()
