"""Download the Drive folder into data/raw/ keeping the same folder structure.

Drive layout (what you have):
    images/<Period>/<Site>/<file>.jpg
Local layout (what we create):
    data/raw/<Period>/<Site>/<file>.jpg

Usage:
    pip install gdown
    python scripts/download_drive_images.py
NOTE: gdown only works if the Drive folder is shared as "Anyone with the link",
and it stops at 50 files per folder. If you hit that, use rclone or download
the folder as a ZIP from the Drive website, then unzip into data/raw/.
"""
import argparse
import sys

FOLDER_ID = "1nUX4L6JQjkW-DuMDYn-E22_CmEAEgUGf"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="data/raw")
    ap.add_argument("--folder_id", default=FOLDER_ID)
    a = ap.parse_args()
    try:
        import gdown
    except ImportError:
        sys.exit("Run: pip install gdown")
    gdown.download_folder(id=a.folder_id, output=a.out, quiet=False, remaining_ok=True)
    print(f"Done. Check that {a.out}/<Period>/<Site>/ folders exist.")


if __name__ == "__main__":
    main()
