"""How good is the cheap OpenCV inpainting on synthetic VALIDATION pairs?

Run this BEFORE training anything. It gives you a baseline number to beat.
PSNR is higher = closer to the clean image. 'masked' looks only at the
damaged pixels, which is what actually matters.

Usage:
    python scripts/evaluate_baseline.py --split val
"""
import argparse
from pathlib import Path

import cv2
import numpy as np


def psnr(a, b, m=None):
    a, b = a.astype(np.float64), b.astype(np.float64)
    if m is not None:
        if m.sum() == 0:
            return float("nan")
        err = ((a - b) ** 2)[m].mean()
    else:
        err = ((a - b) ** 2).mean()
    return 99.0 if err == 0 else 10 * np.log10(255.0 ** 2 / err)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--split", default="val")
    ap.add_argument("--data", default="data")
    ap.add_argument("--method", default="telea", choices=["telea", "ns"])
    ap.add_argument("--radius", type=int, default=3)
    a = ap.parse_args()

    sfx = "" if a.split == "train" else f"_{a.split}"
    dmg_dir = Path(a.data) / f"synthetic_damaged{sfx}"
    msk_dir = Path(a.data) / f"synthetic_masks{sfx}"
    cln_dir = Path(a.data) / f"synthetic_clean{sfx}"
    flag = cv2.INPAINT_TELEA if a.method == "telea" else cv2.INPAINT_NS

    full, masked, damaged_only = [], [], []
    for p in sorted(dmg_dir.glob("*.png")):
        dmg = cv2.imread(str(p))
        m = cv2.imread(str(msk_dir / f"{p.stem}_mask.png"), 0)
        cln = cv2.imread(str(cln_dir / p.name))
        if dmg is None or m is None or cln is None:
            continue
        mb = m > 127
        rest = cv2.inpaint(dmg, (mb * 255).astype(np.uint8), a.radius, flag)
        full.append(psnr(rest, cln))
        masked.append(psnr(rest, cln, mb))
        damaged_only.append(psnr(dmg, cln))
    if not full:
        raise SystemExit("no pairs found - did you run synthetic_damage_sl.py for this split?")
    print(f"images: {len(full)}")
    print(f"PSNR damaged vs clean (no restoration): {np.nanmean(damaged_only):.2f} dB")
    print(f"PSNR restored vs clean (whole image)  : {np.nanmean(full):.2f} dB")
    print(f"PSNR restored vs clean (damaged area) : {np.nanmean(masked):.2f} dB")


if __name__ == "__main__":
    main()
