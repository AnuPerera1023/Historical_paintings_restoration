"""Make synthetic damage on YOUR images (murals, frescoes, cave paintings).

For every image it makes N damaged versions and saves:
    data/synthetic_damaged/<name>.png      damaged input
    data/synthetic_masks/<name>_mask.png   white = damaged pixels
    data/synthetic_clean/<name>.png        the image before damage (target)
(names follow the repo README convention, so scripts/train_unet_detector.py
 can read data/synthetic_damaged + data/synthetic_masks as-is)

Damage types, picked to match wall paintings rather than oil-on-panel:
    cracks      - branching dark hairlines (plaster/paint cracking)
    scratches   - long thin lines (touching, scraping, graffiti)
    flaking     - irregular patches where paint fell off, showing pale plaster
    stains      - brown water-seepage tint. Added to the image but NOT to the
                  mask (it is a colour problem, not a missing-paint problem)

Usage:
    python scripts/synthetic_damage_sl.py --split train --num_per_image 3
    python scripts/synthetic_damage_sl.py --split val   --num_per_image 1
"""
import argparse
import csv
import re
from pathlib import Path

import cv2
import numpy as np


# ---------- damage primitives (all draw white=255 into a mask) ----------
def crack(mask, rng, depth=0):
    h, w = mask.shape
    x, y = rng.uniform(0, w), rng.uniform(0, h)
    ang = rng.uniform(0, 2 * np.pi)
    steps = int(rng.integers(40, 160)) // (1 + depth)
    thick = 1 if depth else int(rng.integers(1, 3))
    for _ in range(steps):
        ang += rng.normal(0, 0.35)
        L = rng.uniform(2, 7)
        nx, ny = x + L * np.cos(ang), y + L * np.sin(ang)
        cv2.line(mask, (int(x), int(y)), (int(nx), int(ny)), 255, thick)
        x, y = nx, ny
        if depth < 2 and rng.random() < 0.05:
            crack_from(mask, rng, x, y, ang + rng.choice([-1, 1]) * rng.uniform(0.4, 1.1), depth + 1)
        if not (0 <= x < w and 0 <= y < h):
            break


def crack_from(mask, rng, x, y, ang, depth):
    h, w = mask.shape
    for _ in range(int(rng.integers(15, 70))):
        ang += rng.normal(0, 0.4)
        L = rng.uniform(2, 6)
        nx, ny = x + L * np.cos(ang), y + L * np.sin(ang)
        cv2.line(mask, (int(x), int(y)), (int(nx), int(ny)), 255, 1)
        x, y = nx, ny
        if not (0 <= x < w and 0 <= y < h):
            break


def scratch(mask, rng):
    h, w = mask.shape
    p0 = np.array([rng.uniform(0, w), rng.uniform(0, h)])
    ang = rng.uniform(0, 2 * np.pi)
    length = rng.uniform(0.1, 0.5) * max(h, w)
    n = 12
    pts = [p0]
    for _ in range(n):
        ang += rng.normal(0, 0.05)
        pts.append(pts[-1] + (length / n) * np.array([np.cos(ang), np.sin(ang)]))
    pts = np.array(pts, np.int32).reshape(-1, 1, 2)
    cv2.polylines(mask, [pts], False, 255, int(rng.integers(1, 3)))


def flake(mask, rng):
    h, w = mask.shape
    cx, cy = rng.uniform(0, w), rng.uniform(0, h)
    r = rng.uniform(0.01, 0.06) * min(h, w)
    k = 14
    ang = np.linspace(0, 2 * np.pi, k, endpoint=False)
    rad = r * rng.uniform(0.5, 1.4, k)
    pts = np.stack([cx + rad * np.cos(ang), cy + rad * np.sin(ang)], 1).astype(np.int32)
    cv2.fillPoly(mask, [pts], 255)


def stain_layer(shape, rng):
    h, w = shape
    noise = rng.random((h // 16 + 2, w // 16 + 2)).astype(np.float32)
    noise = cv2.resize(noise, (w, h), interpolation=cv2.INTER_CUBIC)
    noise = cv2.GaussianBlur(noise, (0, 0), max(h, w) / 30)
    noise = (noise - noise.min()) / (noise.max() - noise.min() + 1e-6)
    return np.clip((noise - 0.55) * 2.2, 0, 1)  # 0..1 blobs


# ---------- put it together ----------
def damage(img, rng, stains=True):
    h, w = img.shape[:2]
    mask = np.zeros((h, w), np.uint8)
    flake_mask = np.zeros_like(mask)
    scale = max(h, w) / 1024.0

    for _ in range(int(rng.integers(2, 7) * max(scale, 0.5))):
        crack(mask, rng)
    for _ in range(int(rng.integers(0, 5))):
        scratch(mask, rng)
    for _ in range(int(rng.integers(2, 10))):
        flake(flake_mask, rng)
    flake_mask = cv2.GaussianBlur(flake_mask, (0, 0), 1.2)
    flake_mask = (flake_mask > 127).astype(np.uint8) * 255

    out = img.astype(np.float32)
    if stains and rng.random() < 0.6:
        s = stain_layer((h, w), rng)[..., None]
        tint = np.array([40, 70, 110], np.float32)  # BGR brownish
        out = out * (1 - 0.45 * s) + tint * 0.45 * s

    # cracks/scratches: darken
    m = (mask > 0)[..., None]
    out = np.where(m, out * rng.uniform(0.25, 0.55), out)

    # flaking: pale plaster colour with a little noise
    plaster = np.array([185, 205, 220], np.float32) * rng.uniform(0.8, 1.05)
    noise = rng.normal(0, 6, (h, w, 1)).astype(np.float32)
    fm = (flake_mask > 0)[..., None]
    out = np.where(fm, plaster + noise, out)

    full_mask = cv2.bitwise_or(mask, flake_mask)
    return np.clip(out, 0, 255).astype(np.uint8), full_mask


def resize_long(img, max_side):
    h, w = img.shape[:2]
    s = max_side / max(h, w)
    if s >= 1:
        return img
    return cv2.resize(img, (int(w * s), int(h * s)), interpolation=cv2.INTER_AREA)


def safe(s):
    return re.sub(r"[^A-Za-z0-9_-]+", "_", s).strip("_")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--meta", default="data/metadata.csv")
    ap.add_argument("--out", default="data")
    ap.add_argument("--split", default="train", choices=["train", "val", "test"])
    ap.add_argument("--num_per_image", type=int, default=3)
    ap.add_argument("--max_side", type=int, default=1024)
    ap.add_argument("--min_sharpness", type=float, default=0.0,
                    help="skip very blurry photos (see sharpness column)")
    ap.add_argument("--no_stains", action="store_true")
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()

    suffix = "" if a.split == "train" else f"_{a.split}"
    out = Path(a.out)
    d_dmg = out / f"synthetic_damaged{suffix}"
    d_msk = out / f"synthetic_masks{suffix}"
    d_cln = out / f"synthetic_clean{suffix}"
    for d in (d_dmg, d_msk, d_cln):
        d.mkdir(parents=True, exist_ok=True)

    rng = np.random.default_rng(a.seed)
    n = 0
    with open(a.meta) as f:
        for r in csv.DictReader(f):
            if r["split"] != a.split or float(r["sharpness"]) < a.min_sharpness:
                continue
            img = cv2.imread(r["path"])
            if img is None:
                continue
            img = resize_long(img, a.max_side)
            for k in range(a.num_per_image):
                dmg, m = damage(img, rng, stains=not a.no_stains)
                name = f"{safe(r['period'])}__{safe(r['site'])}__{safe(Path(r['file']).stem)}__v{k}"
                cv2.imwrite(str(d_dmg / f"{name}.png"), dmg)
                cv2.imwrite(str(d_msk / f"{name}_mask.png"), m)
                cv2.imwrite(str(d_cln / f"{name}.png"), img)
                n += 1
    print(f"wrote {n} synthetic pairs for split='{a.split}' into {out}/")


if __name__ == "__main__":
    main()
