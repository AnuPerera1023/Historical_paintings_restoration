"""Scan data/raw/<Period>/<Site>/* and write data/metadata.csv.

Why: one table that says, for every image, which period and site it is from,
how big it is, how sharp it is, and which split (train/val/test) it belongs to.

IMPORTANT: the split is done by SITE, not by image. Photos of the same wall
look almost identical; if they land in both train and test, your scores look
better than they really are (data leakage).
"""
import argparse
import csv
import hashlib
from pathlib import Path

import cv2

EXT = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".bmp", ".webp"}


def split_for(site: str) -> str:
    h = int(hashlib.md5(site.encode()).hexdigest(), 16) % 10
    return "train" if h < 7 else ("val" if h < 9 else "test")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default="data/raw")
    ap.add_argument("--out", default="data/metadata.csv")
    a = ap.parse_args()

    raw = Path(a.raw)
    rows = []
    for p in sorted(raw.rglob("*")):
        if p.suffix.lower() not in EXT:
            continue
        rel = p.relative_to(raw).parts
        if len(rel) < 3:  # expect Period/Site/file
            print("skip (not Period/Site/file):", p)
            continue
        period, site = rel[0], rel[1]
        img = cv2.imread(str(p))
        if img is None:
            print("unreadable:", p)
            continue
        h, w = img.shape[:2]
        sharp = cv2.Laplacian(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), cv2.CV_64F).var()
        rows.append(dict(path=str(p), period=period, site=site, file=p.name,
                         width=w, height=h, sharpness=round(sharp, 1),
                         split=split_for(site)))

    Path(a.out).parent.mkdir(parents=True, exist_ok=True)
    with open(a.out, "w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows else ["path"])
        wr.writeheader()
        wr.writerows(rows)

    print(f"{len(rows)} images -> {a.out}")
    for key in ("period", "split"):
        counts = {}
        for r in rows:
            counts[r[key]] = counts.get(r[key], 0) + 1
        print(key, counts)


if __name__ == "__main__":
    main()
